﻿using Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Negocio
{
    public class NLogin
    {
        private DLogin objDLogin = new DLogin();
        public Boolean Validar(int user, string pass)
        {
            return objDLogin.ValidarUsuario(user, pass);
        }
    }
}