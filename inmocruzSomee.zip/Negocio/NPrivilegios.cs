﻿using Datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Negocio
{
    public class NPrivilegios
    {
        private DPrivilegios objDTipo = new DPrivilegios();

        public DataTable ListaTabla()
        {
            return objDTipo.getTabla();
        }

        public void CambiarEstado(int idCU, int idTipo, int estado)
        {
            objDTipo.ActualizarEstado(idCU, idTipo, estado);
        }

        public int idTipo(String name){
            return objDTipo.idTipo(name);
        }
    }
}