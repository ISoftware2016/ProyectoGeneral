﻿using Datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Negocio
{
    public class NAutorizacion
    {
        private DAutorizacion objDAutorizacion = new DAutorizacion();
        public DataTable ListaTabla()
        {
            return objDAutorizacion.getTabla();
        }

        public void CambiarEstado(int id, int estado)
        {
            objDAutorizacion.ActualizarEstado(id, estado);
        }

        internal void InsertarAutorizacion(string p1, string p2, int p3, int Carnet)
        {
            objDAutorizacion.Insertar(p1, p2, p3, Carnet);
        }
    }
}