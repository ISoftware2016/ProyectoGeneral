﻿using Datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Negocio
{
    public class NEstructura
    {
        private DEstructura objDEstructura = new DEstructura();

        public DataTable ListaTabla(int nodo_padre)
        {
            return objDEstructura.getTabla(nodo_padre);
        }

        public int GetNodo(int ci)
        {
            return objDEstructura.getNodo(ci);
        }


        public void InsertarNodo(int ci, int nodo_padre)
        {
            objDEstructura.Insertar(ci, nodo_padre);
        }


        internal void CambiarEstado(int nodo)
        {
            objDEstructura.ActualizarEstado(nodo);
        }
    }
}