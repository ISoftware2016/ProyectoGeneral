﻿using Datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Negocio
{
    public class NInmueble
    {
        private DPersona objDAgente = new DPersona();
        private DTipoInmueble objDTipoInmueble = new DTipoInmueble();
        private DOperacion objDOperacion = new DOperacion();
        private DZona objDZona = new DZona();
        private DImagenInmueble objDImagenInmueble = new DImagenInmueble();
        private DPersonaInmueble objDPersonaInmueble = new DPersonaInmueble();
        private DInmueble objDInmueble = new DInmueble();
        public DataTable ListaTabla()
        {
            return objDAgente.getTabla();
        }

        public DataTable ComboTipo()
        {
            return objDTipoInmueble.getComboTipo();
        }

        public DataTable ComboOperacion()
        {
            return objDOperacion.getComboOperacion();
        }

        public DataTable ComboZona()
        {
            return objDZona.getComboZona();
        }

        public void InsertarInmueble(int code, string calle, string lat, string lon, string sup, string descrip,int precio, int idComboZona, int NroH, int NroB, int idComboTipo, int idComboOp)
        {
            objDInmueble.Insertar(code, calle, lat, lon, sup,descrip, precio, idComboZona, NroH, NroB, idComboTipo, idComboOp);
        }

        public void InsertarImg(int code, string url_img)
        {
            objDImagenInmueble.Insertar(code,url_img);
        }


        public void InsertarPersonaInmueble(int code, int ci)
        {
            objDPersonaInmueble.Insertar(code, ci);
        }

        public bool VerificarCodigo(string code)
        {
            return objDInmueble.Verificar(code);
        }

        public DataTable ObtenerPersonaInmueble(int ci)
        {
            return objDPersonaInmueble.getTabla(ci);
        }

        public DataTable ObtenerInmueble(int code)
        {
            return objDInmueble.GetInmueble(code);
        }

        public String ObtenerCalleAvenida(int code) { return objDInmueble.GetCalleAvenida(code); }

        public String ObtenerLatitud(int code) { return objDInmueble.GetLatitud(code); }

        public String ObtenerLongitud(int code) { return objDInmueble.GetLongitud(code); }

        public String ObtenerSuperficie(int code) { return objDInmueble.GetSuperficie(code); }

        public String ObtenerPrecio(int code) { return objDInmueble.GetPrecio(code); }
        public String ObtenerIdZona(int code) { return objDInmueble.GetIdZona(code); }
        public String ObtenerNroHabitaciones(int code) { return objDInmueble.GetNroHabitaciones(code); }
        public String ObtenerNroBanho(int code) { return objDInmueble.GetNroBanho(code); }
        public String ObtenerIdTipo(int code) { return objDInmueble.GetIdTipo(code); }
        public String ObtenerIdEstado(int code) { return objDInmueble.GetEstado(code); }
        public String ObtenerIdOperacion(int code) { return objDInmueble.GetIdOperacion(code); }
        public string ObtenerDescripcion(int code) { return objDInmueble.GetDescripcion(code); }
        public String ObtenerOperacion(int id)
        {
            return objDOperacion.GetNombre(id);
        }
        public String ObtenerTipo(int id)
        {
            return objDTipoInmueble.GetNombre(id);
        }
        public bool VerificarRegistro(int p, int Carnet)
        {
            return objDPersonaInmueble.VerificarRegistro(p, Carnet);
        }

        public bool ValidarImagenInmueble(int code)
        {
            return objDImagenInmueble.VerificarImagen(code);
        }

        public string ObtenerPrimeraImagenInmueble(int code)
        {
            return objDImagenInmueble.GetPrimeraImagen(code);
        }


        internal int ObtenerCantidadImagenes(int code)
        {
            return objDImagenInmueble.GetCantidaImagen(code);
        }

        internal DataTable ObtenerImagenesInmueble(int codigoInmueble)
        {
            return objDImagenInmueble.GetImagenesInmueble(codigoInmueble);
        }

        internal string ObtenerZona(int id)
        {
            return objDZona.GetNombre(id);
        }

        internal void ModificarInmueble(int code, string calle, string lat, string lon, string sup, string descrip, int precio, int idComboZona, int NroH, int NroB, int idComboTipo, int idComboOp)
        {
            objDInmueble.Modificar(code, calle, lat, lon, sup, descrip, precio, idComboZona, NroH, NroB, idComboTipo, idComboOp);
        }
    }
}