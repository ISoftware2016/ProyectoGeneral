﻿using Datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Negocio
{
    public class NAgente
    {
        private DPersona objDAgente = new DPersona();
        private DLogin objDLogin = new DLogin();

        public DataTable ListaTabla()
        {
            return objDAgente.getTabla();
        }

        public void InsertarAgente(int CI, string Nombres, string App, string fecha, string correo, int telefono)
        {
            objDAgente.Insertar(CI, Nombres, App, fecha, correo, telefono);
        }


        internal void InsertarCredenciales(int CI, string p)
        {
            objDLogin.InsertarCuenta(CI, p);
        }
    }
}