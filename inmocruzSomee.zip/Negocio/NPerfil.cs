﻿using Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Negocio
{
    public class NPerfil
    {
        private DPersona objDPersona = new DPersona();
        private DLogin objDLogin = new DLogin();
        public String ObtenerNombre(int ci)
        {
            return objDPersona.GetNombre(ci);
        }
        public String ObtenerApp(int ci)
        {
            return objDPersona.GetApp(ci);
        }
        public String ObtenerFechaN(int ci)
        {
            return objDPersona.GetFechaN(ci);
        }
        public String ObtenerCorreo(int ci)
        {
            return objDPersona.GetCorreo(ci);
        }
        public String ObtenerTelefono(int ci)
        {
            return objDPersona.GetTelefono(ci);
        }
        public String ObtenerFoto(int ci)
        {
            return objDPersona.GetFoto(ci);
        }     
        public String ObtenerPass(int ci)
        {
            return objDLogin.GetPass(ci);
        }


        public void CambiarPass(int Carnet, string pw)
        {
            objDLogin.SetPass(Carnet,pw);
        }

        public void ActualizarDatos(int Carnet, string p1, string p2, string p3, string p4, string p5)
        {
            objDPersona.SetDatos(Carnet, p1, p2, p3, p4, p5);
        }
    }
}