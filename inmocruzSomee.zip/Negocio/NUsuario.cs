﻿using Datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Negocio
{
    public class NUsuario
    {
        private DPersona objDUsuario = new DPersona();

        public DataTable ListaTabla()
        {
            return objDUsuario.getTabla();
        }
    }
}