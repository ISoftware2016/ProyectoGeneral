﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Datos
{
    public class DEstructura
    {
        public string NombreTabla = "NODO";
        private conexion con = new conexion();
        public DataTable getTabla(int NODO_PADRE)
        {
            string sql = "SELECT * FROM " + NombreTabla + " WHERE " + NODO_PADRE + " = ID_NODOPADRE AND ESTADO = 1 ";
            con.crearComando(sql);
            return con.ObtenerConsulta();
        }


        internal int getNodo(int ci)
        {
            con.crearComando("SELECT ID_NODO FROM " + NombreTabla + " WHERE ID_PERSONA = " + ci);
            return Convert.ToInt32(con.ObtenerInformacion());
        }

        internal void Insertar(int ci, int nodo_padre)
        {
            string Sql;
            Sql = "INSERT INTO " + NombreTabla +
 "(ID_PERSONA,ID_NODOPADRE,ESTADO) " +
                "VALUES " +
 "(@ID_PERSONA, @ID_NODOPADRE,@ESTADO) " +
                "SELECT @@Identity";
            con.crearComando(Sql);
            con.AdicionarParametro("@ID_PERSONA", ci);
            con.AdicionarParametro("@ID_NODOPADRE", nodo_padre);
            con.AdicionarParametro("@ESTADO", 0);
            con.Insert();
        }

        internal void ActualizarEstado(int nodo)
        {
            string sql = "update NODO set ESTADO = " + 1 + " where ID_NODOPADRE = " + nodo;
            con.crearComando(sql);
            con.Actualizar();
        }
    }
}