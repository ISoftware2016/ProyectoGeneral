﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Datos
{
    public class DCasoUso
    {
        conexion con = new conexion();
        public String NombreCU(int PaqueteCU, int orden, int idTipo)
        {
            con.crearComando("Select CU.NOMBRE from CASO_USO CU, CU_PAQUETE CUP, TIPO_CU TCU, TIPO T  where T.ID_TIPO = " + idTipo + " and CU.ID_CU = TCU.ID_CU AND TCU.ID_TIPO = T.ID_TIPO and TCU.ESTADO = 1 and CU.ID_CU = CUP.ID_CU and CUP.ID_PAQUETE = " + PaqueteCU + " and CUP.NROORDEN = " + orden);
            return con.ObtenerInformacion();
        }
    }
}