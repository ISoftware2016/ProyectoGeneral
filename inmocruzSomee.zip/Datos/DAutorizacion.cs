﻿using Datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Datos
{
    public class DAutorizacion
    {
        public string NombreTabla = "AUTORIZACION";
        private conexion con = new conexion();
        public DataTable getTabla()
        {
            string sql = "SELECT ID as Nro, USUARIO as Agente, DESCRIPCION as Descripcion , FECHA as Fecha " +
                " FROM " + NombreTabla + " WHERE ESTADO = 1";
            con.crearComando(sql);
            return con.ObtenerConsulta();
        }
        public void ActualizarEstado(int id, int estado)
        {
            string sql = "update " + NombreTabla + " set ESTADO = " + estado + " where ID = " + id ;
            con.crearComando(sql);
            con.Actualizar();
            
        }
        public void Insertar(string agente, string descripcion, int ID_INMUEBLE, int ID_USUARIO)
        {
            DateTime hoy = DateTime.Today;
            DateTime limite = DateTime.Today.AddMonths(2);
            string Sql;
            Sql = "INSERT INTO " + NombreTabla +
                "(USUARIO, DESCRIPCION,FECHA,ESTADO,ID_INMUEBLE,ID_USUARIO) " +
                "VALUES " + "(@USUARIO, @DESCRIPCION,@FECHA,@ESTADO,@ID_INMUEBLE,@ID_USUARIO) " +
                "SELECT @@Identity";
            con.crearComando(Sql);

            con.AdicionarParametro("@USUARIO", agente);
            con.AdicionarParametro("@DESCRIPCION", descripcion);
            con.AdicionarParametro("@FECHA", hoy.ToString());
            if (ID_INMUEBLE == 0)
            {
                ID_INMUEBLE = 123;
                con.AdicionarParametro("@ID_INMUEBLE", ID_INMUEBLE);
            }
            else
            {
                con.AdicionarParametro("@ID_INMUEBLE", ID_INMUEBLE);
            }
            con.AdicionarParametro("@ID_USUARIO", ID_USUARIO);
            con.AdicionarParametro("@ESTADO", 1);

            con.Insert();

        }
    }
}