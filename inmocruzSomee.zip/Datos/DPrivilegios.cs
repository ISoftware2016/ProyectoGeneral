﻿using Datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Datos
{
    public class DPrivilegios
    {
        private conexion con = new conexion();
        public DataTable getTabla()
        {
            string sql = "SELECT CU.ID_CU AS ID , T.NOMBRE AS Tipo_Usuario, CU.NOMBRE as Nombre_Menu, TCU.ESTADO AS Estado  FROM TIPO T, CASO_USO CU, TIPO_CU TCU WHERE CU.ID_CU = TCU.ID_CU AND TCU.ID_TIPO = T.ID_TIPO";
            con.crearComando(sql);
            return con.ObtenerConsulta();
        }

        public void ActualizarEstado(int idCU, int idTipo, int estado)
        {
            string sql = "update TIPO_CU set ESTADO = " + estado + " where ID_CU = " + idCU + "and ID_TIPO =  " + idTipo;
            con.crearComando(sql);
            con.Actualizar();
        }

        public int idTipo(string name)
        {
            string sql = "SELECT ID_TIPO FROM TIPO WHERE nombre = '" + name + "'";
            con.crearComando(sql);
            return Convert.ToInt32(con.ObtenerInformacion());
        }
    }
}