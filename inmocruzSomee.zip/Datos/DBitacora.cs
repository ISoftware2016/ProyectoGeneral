﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Datos
{
    public class DBitacora
    {
        private conexion con = new conexion();
        public DataTable getTabla()
        {
            string sql = "SELECT * FROM BITACORA B , DETALLE_BITACORA DB WHERE B.ID_BITACORA = DB.ID_BITACORA ";
            con.crearComando(sql);
            return con.ObtenerConsulta();
        }
    }
}