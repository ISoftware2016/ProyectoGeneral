﻿using Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inmocruz.Presentacion
{
    public partial class ingresoegreso : System.Web.UI.Page
    {
        int Carnet;
        NMenu objNMenu = new NMenu();
        protected void Page_Load(object sender, EventArgs e)
        {
            Carnet = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["User"]);
            if (Carnet == 0)
            {
                Response.Redirect("index.aspx");
            }
            Response.Write(Interfaz());
            String Nombre = objNMenu.NombreCompletoUsuario(Carnet);
            String Cargo = objNMenu.NombreCargo(Carnet);
            int IdCargo = Convert.ToInt32(objNMenu.IdTipo(Carnet));
            lbCargo.Text = lbCargo2.Text = lbCargo3.Text = Nombre + " (" + Cargo + ")";
            String URL_IMG = "images/users/" + Carnet + ".png";
            ima_avatar_izq.ImageUrl = img_Avatar_Up.ImageUrl = img_Avatar_Up2.ImageUrl = URL_IMG;
            Menu();
        }

        #region Encabezado
        String Interfaz()
        {
            return "<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'><meta http-equiv='X-UA-Compatible' content='IE=edge'><meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0'><title>Inmocruz</title>    <link rel='shortcut icon' href='images/cruz.png'>    <link href='css/font-awesome.css' rel='stylesheet'>    <link href='css/simple-line-icons.css' rel='stylesheet'>    <link href='css/jquery-ui.css' rel='stylesheet'>    <link href='css/datepicker.css' rel='stylesheet'>    <link href='css/bootstrap.css' rel='stylesheet'><link href='css/app.css' rel='stylesheet'></head><body class='notransition'>";
        }
        String Modulos(int dato, String NombrePaquete)
        {
            switch (dato)
            {
                case 0: return "<div id='leftSide'><nav class='leftNav scrollable'><ul>";
                case 1: return "<li class='hasSub'><a><span class='navIcon icon-bar-chart'></span><span class='navLabel'>" + NombrePaquete + "</span><span class='fa fa-angle-left arrowRight'></span></a>";
                case 2: return "<li class='hasSub'><a><span class='navIcon icon-list'></span><span class='navLabel'>" + NombrePaquete + "</span><span class='fa fa-angle-left arrowRight'></span></a>";
                case 3: return "<li class='hasSub'><a><span class='navIcon icon-home'></span><span class='navLabel'>" + NombrePaquete + "</span><span class='fa fa-angle-left arrowRight'></span></a>";
                case 4: return "<li class='hasSub'><a><span class='navIcon icon-graph'></span><span class='navLabel'>" + NombrePaquete + "</span><span class='fa fa-angle-left arrowRight'></span></a>";
                case 5: return "</ul></nav>";
                default: return "";
            }
        }
        String CasoDeUso(String NombreCU)
        {
            switch (NombreCU)
            {
                case "Autorizar Publicación": return "<li><a href='autorizar.aspx'>" + NombreCU + "</a></li>"; ;
                case "Gestionar Estructura": return "<li><a href='estructura.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Agente": return "<li><a href='agente.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Tipo de Usuario": return "<li><a href='tipo.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Usuario": return "<li><a href='usuario.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Perfil": return "<li><a href='perfil.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Reglas": return "<li><a href='reglas.aspx'>" + NombreCU + "</a></li>";
                case "Asignar Privilegio": return "<li><a href='privilegios.aspx'>" + NombreCU + "</a></li>";
                case "Generar Bitácora": return "<li><a href='bitacora.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Inmueble": return "<li><a href='inmueble.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Publicación": return "<li><a href='publicacion.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Comisión": return "<li><a href='comision.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Ingresos y Egresos": return "<li><a href='ingresoegreso.aspx'>" + NombreCU + "</a></li>";
                case "Vender Inmueble": return "<li><a href='venderinmueble.aspx'>" + NombreCU + "</a></li>";
                default: return "";
            }
        }
        void Menu()
        {
            Response.Write(Modulos(0, ""));
            for (int i = 1; i <= 4; i++)
            {
                String print = Modulos(i, objNMenu.NombrePaquete(i));
                Response.Write(print);
                SubMenu(i);
            }
            Response.Write(Modulos(5, ""));
        }
        void SubMenu(int idModulo)
        {
            Response.Write("<ul class='colors'>");
            int i = 1;
            int n = objNMenu.CantidadCUpaquete(idModulo);
            while (i <= n)
            {
                Response.Write(CasoDeUso(objNMenu.NombreCU(idModulo, i, Convert.ToInt32(objNMenu.IdTipo(Carnet)))));
                i++;
            }
            Response.Write("</ul></li>");
        }
        void Mensaje(String contenido)
        {
            this.Page.Response.Write("<script language='JavaScript'>window.alert('" + contenido + "');</script>");
        }
        #endregion
    }
}