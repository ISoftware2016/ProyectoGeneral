﻿using Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inmocruz.Presentacion
{
    public partial class index : System.Web.UI.Page
    {
        private NLogin objNLogin = new NLogin();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void inicioSesion_Click(object sender, EventArgs e)
        {
            int user = Convert.ToInt32(txtuser.Text);
            String pass = txtpass.Text;
            Boolean sw = objNLogin.Validar(user, pass);
            if (sw)
            {
                System.Configuration.ConfigurationManager.AppSettings["User"] = user + "";
                System.Configuration.ConfigurationManager.AppSettings["pre_inmueble"] = "no";
                Response.Redirect("principal.aspx");
            }
            else
            {
                Response.Redirect("index.aspx");
            }
        }
    }
}