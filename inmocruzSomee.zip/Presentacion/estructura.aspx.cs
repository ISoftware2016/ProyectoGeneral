﻿using Negocio;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inmocruz.Presentacion
{
    public partial class estructura : System.Web.UI.Page
    {
        int Carnet;
        NMenu objNMenu = new NMenu();
        NEstructura objEstructura = new NEstructura();
        protected void Page_Load(object sender, EventArgs e)
        {
            Carnet = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["User"]);
            if (Carnet == 0)
            {
                Response.Redirect("index.aspx");
            }
            Response.Write(Interfaz());
            String Nombre = objNMenu.NombreCompletoUsuario(Carnet);
            String Cargo = objNMenu.NombreCargo(Carnet);
            int IdCargo = Convert.ToInt32(objNMenu.IdTipo(Carnet));
            lbCargo.Text = lbCargo2.Text = lbCargo3.Text = Nombre + " (" + Cargo + ")";
            String URL_IMG = "images/users/" + Carnet + ".png";
            ima_avatar_izq.ImageUrl = img_Avatar_Up.ImageUrl = img_Avatar_Up2.ImageUrl = URL_IMG;
            Menu();
            ArmarEstructura();

        }

        #region Encabezado
        String Interfaz()
        {
            return "<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'><meta http-equiv='X-UA-Compatible' content='IE=edge'>" +
            "<meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0'><title>Inmocruz</title> " +
            "   <link rel='shortcut icon' href='images/cruz.png'>  " +
                " <link href='css/font-awesome.css' rel='stylesheet'> " +
    " <link href='css/simple-line-icons.css' rel='stylesheet'> " +
    " <link href='css/jquery-ui.css' rel='stylesheet'> " +
    " <link href='css/datepicker.css' rel='stylesheet'> " +
    " <link href='css/bootstrap.css' rel='stylesheet'> " +
    " <link href='css/app.css' rel='stylesheet'> " +


    " <link href='arbol/jquerysctipttop.css' rel='stylesheet' /> " +
    " <link href='arbol/jquery.orgchart.css' media='all' rel='stylesheet' type='text/css' /> " +
    " <link href='arbol/Chart.css' rel='stylesheet' /> " +


    " <script src='js/jquery-2.1.1.min.js'></script> " +
    " <script src='js/jquery-ui.min.js'></script> " +
    " <script src='js/jquery-ui-touch-punch.js'></script> " +
    " <script src='js/jquery.placeholder.js'></script> " +
    " <script src='js/bootstrap.js'></script> " +
    " <script src='js/jquery.touchSwipe.min.js'></script> " +
    " <script src='js/jquery.slimscroll.min.js'></script> " +
    " <script src='js/infobox.js'></script> " +
    " <script src='js/jquery.tagsinput.min.js'></script> " +
    " <script src='js/bootstrap-datepicker.js'></script> " +
    " <script src='js/app.js' type='text/javascript'></script> " +



    "<script src='arbol/jquery-1.11.1.min.js'> </script> " +
    "<script src='arbol/jquery.orgchart.js' type='text/javascript'> </script> " +


                "</head><body class='notransition'>";
        }
        String Modulos(int dato, String NombrePaquete)
        {
            switch (dato)
            {
                case 0: return "<div id='leftSide'><nav class='leftNav scrollable'><ul>";
                case 1: return "<li class='hasSub'><a><span class='navIcon icon-bar-chart'></span><span class='navLabel'>" + NombrePaquete + "</span><span class='fa fa-angle-left arrowRight'></span></a>";
                case 2: return "<li class='hasSub'><a><span class='navIcon icon-list'></span><span class='navLabel'>" + NombrePaquete + "</span><span class='fa fa-angle-left arrowRight'></span></a>";
                case 3: return "<li class='hasSub'><a><span class='navIcon icon-home'></span><span class='navLabel'>" + NombrePaquete + "</span><span class='fa fa-angle-left arrowRight'></span></a>";
                case 4: return "<li class='hasSub'><a><span class='navIcon icon-graph'></span><span class='navLabel'>" + NombrePaquete + "</span><span class='fa fa-angle-left arrowRight'></span></a>";
                case 5: return "</ul></nav>";
                default: return "";
            }
        }
        String CasoDeUso(String NombreCU)
        {
            switch (NombreCU)
            {
                case "Autorizar Publicación": return "<li><a href='autorizar.aspx'>" + NombreCU + "</a></li>"; ;
                case "Gestionar Estructura": return "<li><a href='estructura.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Agente": return "<li><a href='agente.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Tipo de Usuario": return "<li><a href='tipo.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Usuario": return "<li><a href='usuario.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Perfil": return "<li><a href='perfil.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Reglas": return "<li><a href='reglas.aspx'>" + NombreCU + "</a></li>";
                case "Asignar Privilegio": return "<li><a href='privilegios.aspx'>" + NombreCU + "</a></li>";
                case "Generar Bitácora": return "<li><a href='bitacora.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Inmueble": return "<li><a href='inmueble.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Publicación": return "<li><a href='publicacion.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Comisión": return "<li><a href='comision.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Ingresos y Egresos": return "<li><a href='ingresoegreso.aspx'>" + NombreCU + "</a></li>";
                case "Vender Inmueble": return "<li><a href='venderinmueble.aspx'>" + NombreCU + "</a></li>";
                default: return "";
            }
        }
        void Menu()
        {
            Response.Write(Modulos(0, ""));
            for (int i = 1; i <= 4; i++)
            {
                String print = Modulos(i, objNMenu.NombrePaquete(i));
                Response.Write(print);
                SubMenu(i);
            }
            Response.Write(Modulos(5, ""));
        }
        void SubMenu(int idModulo)
        {
            Response.Write("<ul class='colors'>");
            int i = 1;
            int n = objNMenu.CantidadCUpaquete(idModulo);
            while (i <= n)
            {
                Response.Write(CasoDeUso(objNMenu.NombreCU(idModulo, i, Convert.ToInt32(objNMenu.IdTipo(Carnet)))));
                i++;
            }
            Response.Write("</ul></li>");
        }
        void Mensaje(String contenido)
        {
            this.Page.Response.Write("<script language='JavaScript'>window.alert('" + contenido + "');</script>");
        }
        #endregion

        public void ArmarEstructura()
        {
            MyArbol.InnerHtml = "<script type='text/javascript'> ";
            MyArbol.InnerHtml += "var testData = [ ";

            int NODO_PADRE = objEstructura.GetNodo(Carnet);
            MyArbol.InnerHtml += "   { id:" + NODO_PADRE + ", name: ' <p class=help-block> (" + Carnet + ") <br> " + objNMenu.NombreCompletoUsuario(Carnet) + "<p>', parent: 0 }, ";

            DataTable item_inmueble = objEstructura.ListaTabla(NODO_PADRE);
            foreach (DataRow item in item_inmueble.Rows)
            {
                MyArbol.InnerHtml += "   { id: " + item[0] +
                    ", name: ' <p class=help-block> (" + item[1] + ") <br> " +
                    objNMenu.NombreCompletoUsuario((int)item[1]) + "<p>', parent: " + item[2] + " }, ";
                DataTable item_inmueble1 = objEstructura.ListaTabla(objEstructura.GetNodo((int)item[1]));
                foreach (DataRow item1 in item_inmueble1.Rows)
                {
                    MyArbol.InnerHtml += "   { id: " + item1[0] +
                        ", name: ' <p class=help-block> (" + item1[1] + ") <br> " +
                        objNMenu.NombreCompletoUsuario((int)item1[1]) + "<p>', parent: " + item1[2] + " }, ";

                    DataTable item_inmueble2 = objEstructura.ListaTabla(objEstructura.GetNodo((int)item1[1]));
                    foreach (DataRow item2 in item_inmueble2.Rows)
                    {
                        MyArbol.InnerHtml += "   { id: " + item2[0] +
                            ", name: ' <p class=help-block> (" + item2[1] + ") <br> " +
                            objNMenu.NombreCompletoUsuario((int)item2[1]) + "<p>', parent: " + item2[2] + " }, ";

                    }

                }

            }
            //MyArbol.InnerHtml += "   { id: 2, name: 'CEO Office', parent: 1 }, ";
            //MyArbol.InnerHtml += "   { id: 3, name: 'Division 1', parent: 1 }, ";
            //MyArbol.InnerHtml += "   { id: 4, name: 'Division 2', parent: 1 }, ";
            //MyArbol.InnerHtml += "   { id: 9, name: 'Division new', parent: 6 }, ";
            //MyArbol.InnerHtml += "   { id: 6, name: 'Division 3', parent: 1 }, ";
            //MyArbol.InnerHtml += "   { id: 7, name: 'Division 44444 44  ', parent: 1 }, ";
            //MyArbol.InnerHtml += "   { id: 8, name: 'Division 5', parent: 1 }, ";
            //MyArbol.InnerHtml += "   { id: 5, name: 'Sub Division', parent: 3 }, ";
            MyArbol.InnerHtml += "]; ";
            MyArbol.InnerHtml += "</script> ";

        }



    }

}