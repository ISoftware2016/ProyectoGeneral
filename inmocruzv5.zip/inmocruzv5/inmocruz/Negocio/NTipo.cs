﻿using Datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Negocio
{
    public class NTipo
    {
        private DTipo objDTipo = new DTipo();

        public DataTable ListaTabla()
        {
            return objDTipo.getTabla();
        }

        public void ModificarTipo(int idTipo, string name, string descrip)
        {
            objDTipo.Modificar(idTipo, name, descrip);
        }
    }
}