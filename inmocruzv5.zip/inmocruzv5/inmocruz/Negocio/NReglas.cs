﻿using Datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Negocio
{
    public class NReglas
    {
        private DComision objDComision = new DComision();
        private DTipo objDTipo = new DTipo();

        public DataTable ListaTabla()
        {
            return objDComision.getTabla();
        }
        public void ActualizarMontoComision(int idNivel, int Monto)
        {
            objDComision.ActualizarMonto(idNivel, Monto);
        }

        public int ObtenerMonto(int idNivel)
        {
            return objDComision.ObtenerMonto(idNivel);
        }
        public void ActualizarPermanencia(int Nro)
        {
            objDTipo.ActualizarPermanencia(Nro);
        }

        public int ObtenerPermanencia()
        {
            return objDTipo.ObtenerPermanencia();
        }
    }
}