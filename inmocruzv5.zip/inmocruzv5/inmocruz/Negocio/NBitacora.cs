﻿using Datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Negocio
{
    public class NBitacora
    {
        private DBitacora objDAgente = new DBitacora();
        public DataTable ListaTabla()
        {
            return objDAgente.getTabla();
        }
    }
}