﻿using Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Negocio
{
    public class NMenu
    {

        private DPaquete objDPaquete = new DPaquete();
        private DCasoUso objDCasoUso = new DCasoUso();
        private DPersona objDPersona = new DPersona();

        public String NombreCargo(int usuario)
        {
            return objDPersona.GetCargo(usuario);
        }

        public String NombreCompletoUsuario(int usuario)
        {
            return objDPersona.GetNombreCompleto(usuario);
        }

        public String IdTipo(int usuario)
        {
            return objDPersona.GetIDCargo(usuario);
        }

        public String NombreCU(int PaqueteCU, int orden,int idTipo)
        {
            return objDCasoUso.NombreCU(PaqueteCU, orden, idTipo);
        }

        public String NombrePaquete(int id)
        {
            return objDPaquete.NombrePaquete(id);
        }

        public int CantidadCUpaquete(int idPaquete)
        {
            return objDPaquete.CantidadCUpaquete(idPaquete);
        }

    }
}