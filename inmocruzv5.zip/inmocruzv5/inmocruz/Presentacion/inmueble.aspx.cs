﻿using Negocio;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inmocruz.Presentacion
{
    public partial class inmueble : System.Web.UI.Page
    {
        int Carnet;
        string ver, modificar, LATG,LONG;
        NMenu objNMenu = new NMenu();
        NInmueble objNInmueble = new NInmueble();
        protected void Page_Load(object sender, EventArgs e)
        {
            txtCode.Text = Request.QueryString["code"];
            txtCode.Enabled = false;
            ver = Request.QueryString["ver"];
            modificar = Request.QueryString["modif"];
            if (this.IsPostBack)
            {
                LATG = Request.Form[hfNameLAT.UniqueID];
                LONG = Request.Form[hfNameLON.UniqueID];
            }
       //     String lat = Request.Form["latitude"];//latitude.InnerText;
       //     String lon = longitude.InnerText;
          ///  MouseUP();
            if (txtCode.Text != "")
            {
                Carnet =  Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["User"]);
                if (!IsPostBack)
                {
                    if (Carnet == 0)
                    {
                        Response.Redirect("index.aspx");
                    }
                    Response.Write(Interfaz());
                    String Nombre = objNMenu.NombreCompletoUsuario(Carnet);
                    String Cargo = objNMenu.NombreCargo(Carnet);
                    int IdCargo = Convert.ToInt32(objNMenu.IdTipo(Carnet));
                    lbCargo.Text = lbCargo2.Text = lbCargo3.Text = Nombre + " (" + Cargo + ")";
                    String URL_IMG = "images/users/" + Carnet + ".png";
                    ima_avatar_izq.ImageUrl = img_Avatar_Up.ImageUrl = img_Avatar_Up2.ImageUrl = URL_IMG;

                    Menu();
                    ListarComboZona();
                    ListarComboTipo();
                    ListarComboOperacion();

                    detallesInmueble.Visible = false;
                    btnMODIF.Visible = false;
                    if (modificar == "ok")
                    {
                        btnMODIF.Visible = true;
                        btnNEW.Visible = false;
                        detallesInmueble.Visible = false;
                        int code = Convert.ToInt32(txtCode.Text);
                        address.Text = objNInmueble.ObtenerCalleAvenida(code);

                        LATG = latitude.InnerHtml = objNInmueble.ObtenerLatitud(code);
                        LONG =longitude.InnerHtml = objNInmueble.ObtenerLongitud(code);

                        txtSuperficie.Text = objNInmueble.ObtenerSuperficie(code);
                        txtDescrip.Text = objNInmueble.ObtenerDescripcion(code);
                        txtNroH.Text = objNInmueble.ObtenerNroHabitaciones(code);
                        txtNroB.Text = objNInmueble.ObtenerNroBanho(code);
                        txtPrecio.Text = objNInmueble.ObtenerPrecio(code);
                        dropZona.SelectedItem.Text = objNInmueble.ObtenerZona(Convert.ToInt32(objNInmueble.ObtenerIdZona(code)));
                        dropTipo.SelectedItem.Text = objNInmueble.ObtenerTipo(Convert.ToInt32(objNInmueble.ObtenerIdTipo(code)));
                        dropOperacion.SelectedItem.Text = objNInmueble.ObtenerOperacion(Convert.ToInt32(objNInmueble.ObtenerIdOperacion(code)));

                    }
                }
            }
            else
            {
                Response.Redirect("pre_inmueble.aspx");
            }
#region ver detalle
            if (ver == "ok")
            {
                detallesInmueble.Visible = true;
                insertarInmueble.Visible = false;
                home.Visible = false;
                elTab.Visible = false;
                int codigoInmueble = Convert.ToInt32(txtCode.Text);
                descripcionVer.InnerText = objNInmueble.ObtenerDescripcion(codigoInmueble);
                pageTitle.InnerText = "Inmueble en " + objNInmueble.ObtenerOperacion(Convert.ToInt32(objNInmueble.ObtenerIdOperacion(codigoInmueble)));
                Domitorios.InnerText = objNInmueble.ObtenerNroHabitaciones(codigoInmueble) + " Habitaciones";
                banio.InnerText = objNInmueble.ObtenerNroBanho(codigoInmueble) + " Baños";
                VerAvenida.Text += objNInmueble.ObtenerCalleAvenida(codigoInmueble);
                superficie.InnerText = objNInmueble.ObtenerSuperficie(codigoInmueble);
                if (objNInmueble.ValidarImagenInmueble(codigoInmueble))
                {
                    int cuantas_img = objNInmueble.ObtenerCantidadImagenes(codigoInmueble);
                    int i = 0;
                    carouselFull.InnerHtml += "<ol class='carousel-indicators'>";
                    bool first = true;
                    while (i < cuantas_img)
                    {
                        if (first)
                        {
                            carouselFull.InnerHtml += "<li data-target='#carouselFull' data-slide-to='" + i + "' class='active'></li>";
                            first = false;
                        }
                        else
                        {
                            carouselFull.InnerHtml += "<li data-target='#carouselFull' data-slide-to='" + i + "'></li>";
                            i++;
                        }
                    }
                    carouselFull.InnerHtml += "</ol>";
                    carouselFull.InnerHtml += "<div class='carousel-inner'>";
                    DataTable item_inmueble = objNInmueble.ObtenerImagenesInmueble(codigoInmueble);
                    bool primero = true;
                    foreach (DataRow item in item_inmueble.Rows)
                    {
                        if (primero)
                        {
                            carouselFull.InnerHtml +=
                            "<div class='item active'>" +
                               "<img src='" + item[2] + "' alt='First slide'>" +
                                   "<div class='container'>" +
                                         "<div class='carousel-caption'>" +
                                         "</div>" +
                                   "</div>" +
                           "</div>";
                            primero = false;
                        }
                        else
                        {
                            carouselFull.InnerHtml +=
                            "<div class='item'>" +
                               "<img src='" + item[2] + "' alt='First slide'>" +
                                   "<div class='container'>" +
                                         "<div class='carousel-caption'>" +
                                         "</div>" +
                                   "</div>" +
                           "</div>";
                        }
                    }
                    carouselFull.InnerHtml += "</div>" +
 "<a class='left carousel-control' href='#carouselFull' role='button' data-slide='prev'><span class='fa fa-chevron-left'></span></a>" +
 "<a class='right carousel-control' href='#carouselFull' role='button' data-slide='next'><span class='fa fa-chevron-right'></span></a>";

                }

                
                LATG = latitude1.InnerHtml = objNInmueble.ObtenerLatitud(codigoInmueble);
                LONG = longitude1.InnerHtml = objNInmueble.ObtenerLongitud(codigoInmueble);
            }
#endregion

            literal();
        }

        void literal()
        {
            if (LATG == null)
            {
               LATG = "-17.784127174241902";
               LONG = "-63.180435782958966";
            }
            literalTEXT.Text =  ("<script type='text/javascript'> (function ($) {'use strict';setTimeout(function() {");
            literalTEXT.Text += ("$('body').removeClass('notransition');");

            literalTEXT.Text += (" map = new google.maps.Map(document.getElementById('mapView'), options);");
            literalTEXT.Text += (" var styledMapType = new google.maps.StyledMapType(styles, {");
            literalTEXT.Text += ("name : 'Styled'");
            literalTEXT.Text += ("});");
            literalTEXT.Text += ("map.mapTypes.set('Styled', styledMapType);");
            literalTEXT.Text += ("map.setCenter(new google.maps.LatLng(" + LATG + ", " + LONG + "));");
            literalTEXT.Text += ("map.setZoom(14);");

          //  literalTEXT.Text += ("if ($('#address').length > 0) {");
            literalTEXT.Text += ("if (true) {");
            literalTEXT.Text += ("newMarker = new google.maps.Marker({");
            literalTEXT.Text += ("position: new google.maps.LatLng(" + LATG + ", "+LONG+"),");
            literalTEXT.Text += ("map: map,");
            literalTEXT.Text += ("icon: new google.maps.MarkerImage(");
            literalTEXT.Text += ("'images/marker-new.png',");
            literalTEXT.Text += (" null,");
            literalTEXT.Text += (" null,");
            // new google.maps.Point(0,0),
            literalTEXT.Text += (" null,");
            literalTEXT.Text += ("new google.maps.Size(36, 36)");
            literalTEXT.Text += ("),");
            literalTEXT.Text += (" draggable: true,");
            literalTEXT.Text += (" animation: google.maps.Animation.DROP,");
            literalTEXT.Text += (" });");
            

            literalTEXT.Text += ("\n google.maps.event.addListener(newMarker, 'mouseup', function(event) {");
            literalTEXT.Text += ("\n  var latitude = this.position.lat();");
            literalTEXT.Text += ("\n  var longitude = this.position.lng();");
            literalTEXT.Text += ("\n $('#latitude').text(this.position.lat());");
            literalTEXT.Text += ("\n $('#longitude').text(this.position.lng());");
            literalTEXT.Text += ("\n $('#latitude1').text(this.position.lat());");
            literalTEXT.Text += ("\n $('#longitude1').text(this.position.lng());");


        //    literalTEXT.Text += ("\n alert('lat ' + latitude)");
            literalTEXT.Text += ("\n });");
            literalTEXT.Text += ("\n  }");
            literalTEXT.Text += ("\n  addMarkers(props, map);");
            literalTEXT.Text += ("\n  }, 300);");
           
        }

        private void ListarComboZona()
        {
            DataTable sJson = objNInmueble.ComboZona();
            dropZona.DataSource = sJson;
            dropZona.DataValueField = "ID_ZONA";
            dropZona.DataTextField = "NOMBRE";
            dropZona.DataBind();
        }
        private void ListarComboTipo()
        {
            DataTable sJson = objNInmueble.ComboTipo();
            dropTipo.DataSource = sJson;
            dropTipo.DataValueField = "ID_INMUEBLE";
            dropTipo.DataTextField = "NOMBRE";
            dropTipo.DataBind();
        }
        private void ListarComboOperacion()
        {
            DataTable sJson = objNInmueble.ComboOperacion();
            dropOperacion.DataSource = sJson;
            dropOperacion.DataValueField = "ID_OPERACION";
            dropOperacion.DataTextField = "NOMBRE";
            dropOperacion.DataBind();
        }


        #region Encabezado
        String Interfaz()
        {
            return "<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'><meta http-equiv='X-UA-Compatible' content='IE=edge'><meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0'><title>Inmocruz</title>    <link rel='shortcut icon' href='images/cruz.png'>    <link href='css/font-awesome.css' rel='stylesheet'>    <link href='css/simple-line-icons.css' rel='stylesheet'>    <link href='css/jquery-ui.css' rel='stylesheet'>    <link href='css/datepicker.css' rel='stylesheet'>  <link href='css/fileinput.min.css' rel='stylesheet'>  <link href='css/bootstrap.css' rel='stylesheet'><link href='css/app.css' rel='stylesheet'></head><body class='notransition'>";
        }
        String Modulos(int dato, String NombrePaquete)
        {
            switch (dato)
            {
                case 0: return "<div id='leftSide'><nav class='leftNav scrollable'><ul>";
                case 1: return "<li class='hasSub'><a><span class='navIcon icon-bar-chart'></span><span class='navLabel'>" + NombrePaquete + "</span><span class='fa fa-angle-left arrowRight'></span></a>";
                case 2: return "<li class='hasSub'><a><span class='navIcon icon-list'></span><span class='navLabel'>" + NombrePaquete + "</span><span class='fa fa-angle-left arrowRight'></span></a>";
                case 3: return "<li class='hasSub'><a><span class='navIcon icon-home'></span><span class='navLabel'>" + NombrePaquete + "</span><span class='fa fa-angle-left arrowRight'></span></a>";
                case 4: return "<li class='hasSub'><a><span class='navIcon icon-graph'></span><span class='navLabel'>" + NombrePaquete + "</span><span class='fa fa-angle-left arrowRight'></span></a>";
                case 5: return "</ul></nav>";
                default: return "";
            }
        }
        String CasoDeUso(String NombreCU)
        {
            switch (NombreCU)
            {
                case "Autorizar Publicación": return "<li><a href='autorizar.aspx'>" + NombreCU + "</a></li>"; ;
                case "Gestionar Estructura": return "<li><a href='estructura.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Agente": return "<li><a href='agente.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Tipo de Usuario": return "<li><a href='tipo.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Usuario": return "<li><a href='usuario.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Perfil": return "<li><a href='perfil.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Reglas": return "<li><a href='reglas.aspx'>" + NombreCU + "</a></li>";
                case "Asignar Privilegio": return "<li><a href='privilegios.aspx'>" + NombreCU + "</a></li>";
                case "Generar Bitácora": return "<li><a href='bitacora.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Inmueble": return "<li><a href='inmueble.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Publicación": return "<li><a href='publicacion.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Comisión": return "<li><a href='comision.aspx'>" + NombreCU + "</a></li>";
                case "Gestionar Ingresos y Egresos": return "<li><a href='ingresoegreso.aspx'>" + NombreCU + "</a></li>";
                case "Vender Inmueble": return "<li><a href='venderinmueble.aspx'>" + NombreCU + "</a></li>";
                default: return "";
            }
        }
        void Menu()
        {
            Response.Write(Modulos(0, ""));
            for (int i = 1; i <= 4; i++)
            {
                String print = Modulos(i, objNMenu.NombrePaquete(i));
                Response.Write(print);
                SubMenu(i);
            }
            Response.Write(Modulos(5, ""));
        }
        void SubMenu(int idModulo)
        {
            Response.Write("<ul class='colors'>");
            int i = 1;
            int n = objNMenu.CantidadCUpaquete(idModulo);
            while (i <= n)
            {
                Response.Write(CasoDeUso(objNMenu.NombreCU(idModulo, i, Convert.ToInt32(objNMenu.IdTipo(Carnet)))));
                i++;
            }
            Response.Write("</ul></li>");
        }
        void Mensaje(String contenido)
        {
            this.Page.Response.Write("<script language='JavaScript'>window.alert('" + contenido + "');</script>");
        }
        #endregion

        protected void btnNEW_Click(object sender, EventArgs e)
        {
            int code = Convert.ToInt32(txtCode.Text);
            String calle = address.Text;
            String lat = latitude.InnerHtml;
            String lon = longitude.InnerText;
            String sup = txtSuperficie.Text;
            String descrip = txtDescrip.Text;
            int NroH = Convert.ToInt32(txtNroH.Text);
            int NroB = Convert.ToInt32(txtNroB.Text);
            int precio = Convert.ToInt32(txtPrecio.Text);
            int idComboZona = Convert.ToInt32(dropZona.SelectedItem.Value.ToString());
            int idComboTipo = Convert.ToInt32(dropTipo.SelectedItem.Value.ToString());
            int idComboOp = Convert.ToInt32(dropOperacion.SelectedItem.Value.ToString());

            objNInmueble.InsertarInmueble(code, calle, lat, lon, sup, descrip, precio, idComboZona, NroH, NroB, idComboTipo, idComboOp);

            if (FileUpload1.FileName != "")
            {
                FileUpload1.SaveAs(Server.MapPath(".") + "/images/" + code + ".png");
            }
            String url_img = "images/" + code + ".png";
            objNInmueble.InsertarImg(code, url_img);

            objNInmueble.InsertarPersonaInmueble(code, Carnet);


            Response.Redirect("inmueble.aspx");
            //    Mensaje("Insertado con exito");


        }

        protected void btnMODIF_Click(object sender, EventArgs e)
        {
            int code = Convert.ToInt32(txtCode.Text);
            String calle = address.Text;
            String lat = LATG;//latitude.InnerHtml;
            String lon = LONG;// longitude.InnerText;
            String sup = txtSuperficie.Text;
            String descrip = txtDescrip.Text;
            int NroH = Convert.ToInt32(txtNroH.Text);
            int NroB = Convert.ToInt32(txtNroB.Text);
            int precio = Convert.ToInt32(txtPrecio.Text);
            int idComboZona = Convert.ToInt32(dropZona.SelectedItem.Value.ToString());
            int idComboTipo = Convert.ToInt32(dropTipo.SelectedItem.Value.ToString());
            int idComboOp = Convert.ToInt32(dropOperacion.SelectedItem.Value.ToString());

            objNInmueble.ModificarInmueble(code, calle, lat, lon, sup, descrip, precio, idComboZona, NroH, NroB, idComboTipo, idComboOp);
            //   ?code=123&ver=ok
            String pasoActualizado = "inmueble.aspx?code=" + code + "&modif=ok";
            Response.Redirect(pasoActualizado);
        }


    }
}