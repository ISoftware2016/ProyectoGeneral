﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Datos
{
    public class DTipo
    {
        public string NombreTabla = "TIPO";
        private conexion con = new conexion();
        public DataTable getTabla()
        {
            string sql = "Select * FROM " + NombreTabla;
            con.crearComando(sql);
            return con.ObtenerConsulta();
        }
        public void ActualizarPermanencia(int PERMANENCIA)
        {
            string sql = "update TIPO set PERMANENCIA = " + PERMANENCIA + " where ID_TIPO = 2";
            con.crearComando(sql);
            con.Actualizar();
        }
        public int ObtenerPermanencia()
        {
            con.crearComando("select PERMANENCIA from TIPO where ID_TIPO = 2 ");
            return Convert.ToInt32(con.ObtenerInformacion());
        }

        public void Modificar(int idTipo, string name, string descrip)
        {
            string sql = "update TIPO set NOMBRE = '" + name + "' , DESCRIPCION = '" + descrip+ "' where ID_TIPO = " + idTipo;
            con.crearComando(sql);
            con.Actualizar();
        }

    }
}