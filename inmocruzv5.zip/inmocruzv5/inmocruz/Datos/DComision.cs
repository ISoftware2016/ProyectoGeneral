﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Datos
{
    public class DComision
    {
        public string NombreTabla = "COMISION";
        private conexion con = new conexion();
        public DataTable getTabla()
        {
            string sql = "SELECT ID_NIVEL as NroNivel , MONTO_COMISION as MontoComision FROM " + NombreTabla;
            con.crearComando(sql);
            return con.ObtenerConsulta();
        }
        public void ActualizarMonto(int idNivel, int Monto)
        {
            string sql = "update COMISION set MONTO_COMISION = " + Monto + " where ID_NIVEL = " + idNivel;
            con.crearComando(sql);
            con.Actualizar();
        }

        public int ObtenerMonto(int idNivel)
        {
            con.crearComando("select MONTO_COMISION from COMISION where ID_NIVEL = " + idNivel);
            return Convert.ToInt32(con.ObtenerInformacion());
        }
    }
}