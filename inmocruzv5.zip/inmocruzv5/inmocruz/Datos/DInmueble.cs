﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Datos
{
    public class DInmueble
    {

        public string NombreTabla = "INMUEBLE";
        private conexion con = new conexion();

        public void Insertar(int code, string calle, string lat, string lon, string sup, string descrip, int precio, int idComboZona, int NroH, int NroB, int idComboTipo, int idComboOp)
        {
            string Sql;
            Sql = "INSERT INTO " + NombreTabla +
 "(CODIGO_INMUEBLE,CALLE_AVENIDA,LATITUD,LONGITUD,SUPERFICIE,DESCRIPCION,PRECIO,ID_ZONA,NRO_HABITACIONES,NRO_BANHO,ID_TIPO,ESTADO,ID_OPERACION) " +
                " VALUES " +
 "(@CODIGO_INMUEBLE, @CALLE_AVENIDA,@LATITUD,@LONGITUD,@SUPERFICIE,@DESCRIPCION,@PRECIO,@ID_ZONA,@NRO_HABITACIONES,@NRO_BANHO,@ID_TIPO,@ESTADO,@ID_OPERACION) " +
                "SELECT @@Identity";
            con.crearComando(Sql);
            con.AdicionarParametro("@CODIGO_INMUEBLE", code);
            con.AdicionarParametro("@CALLE_AVENIDA", calle);
            con.AdicionarParametro("@LATITUD", lat);
            con.AdicionarParametro("@LONGITUD", lon);
            con.AdicionarParametro("@SUPERFICIE", sup);
            con.AdicionarParametro("@DESCRIPCION", descrip);
            con.AdicionarParametro("@PRECIO", precio);
            con.AdicionarParametro("@ID_ZONA", idComboZona);
            con.AdicionarParametro("@NRO_HABITACIONES", NroH);
            con.AdicionarParametro("@NRO_BANHO", NroB);
            con.AdicionarParametro("@ID_TIPO", idComboTipo);
            con.AdicionarParametro("@ESTADO", 1);
            con.AdicionarParametro("@ID_OPERACION", idComboOp);
            con.Insert();
        }


        internal bool Verificar(string code)
        {
            con.crearComando("Select * from " + NombreTabla + "  where CODIGO_INMUEBLE = " + code);
            string consulta = con.ObtenerInformacion();
            if (consulta == "")
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public string GetCalleAvenida(int code)
        {
            con.crearComando("Select CALLE_AVENIDA from " + NombreTabla + " where CODIGO_INMUEBLE = " + code);
            return con.ObtenerInformacion();
        }

        public string GetLatitud(int code)
        {
            con.crearComando("Select LATITUD from " + NombreTabla + " where CODIGO_INMUEBLE = " + code);
            return con.ObtenerInformacion();
        }

        public string GetLongitud(int code)
        {
            con.crearComando("Select LONGITUD from " + NombreTabla + "  where CODIGO_INMUEBLE = " + code);
            return con.ObtenerInformacion();
        }

        public string GetSuperficie(int code)
        {
            con.crearComando("Select SUPERFICIE from " + NombreTabla + "  where CODIGO_INMUEBLE = " + code);
            return con.ObtenerInformacion();
        }


        public string GetPrecio(int code)
        {
            con.crearComando("Select PRECIO from " + NombreTabla + "  where CODIGO_INMUEBLE = " + code);
            return con.ObtenerInformacion();
        }

        public string GetIdZona(int code)
        {
            con.crearComando("Select ID_ZONA from " + NombreTabla + "  where CODIGO_INMUEBLE = " + code);
            return con.ObtenerInformacion();
        }

        public string GetNroHabitaciones(int code)
        {
            con.crearComando("Select NRO_HABITACIONES from " + NombreTabla + "  where CODIGO_INMUEBLE = " + code);
            return con.ObtenerInformacion();
        }

        public string GetNroBanho(int code)
        {
            con.crearComando("Select NRO_BANHO from " + NombreTabla + "  where CODIGO_INMUEBLE = " + code);
            return con.ObtenerInformacion();
        }

        public string GetIdTipo(int code)
        {
            con.crearComando("Select ID_TIPO from " + NombreTabla + "  where CODIGO_INMUEBLE = " + code);
            return con.ObtenerInformacion();
        }

        public string GetIdOperacion(int code)
        {
            con.crearComando("Select ID_OPERACION from " + NombreTabla + "  where CODIGO_INMUEBLE = " + code);
            return con.ObtenerInformacion();
        }

        public DataTable GetInmueble(int code)
        {
            string sql = "SELECT * FROM " + NombreTabla + " WHERE CODIGO_INMUEBLE = " + code.ToString();
            con.crearComando(sql);
            return con.ObtenerConsulta();
        }

        public string GetEstado(int code)
        {
            con.crearComando("Select ESTADO from " + NombreTabla + "  where CODIGO_INMUEBLE = " + code);
            return con.ObtenerInformacion();
        }

        internal string GetDescripcion(int code)
        {
            con.crearComando("Select DESCRIPCION from " + NombreTabla + "  where CODIGO_INMUEBLE = " + code);
            return con.ObtenerInformacion();
        }

        internal void Modificar(int code, string calle, string lat, string lon, string sup, string descrip, int precio, int idComboZona, int NroH, int NroB, int idComboTipo, int idComboOp)
        {
            string SqlUP;

            SqlUP = "update " + NombreTabla + " SET " +
                "CALLE_AVENIDA='"+calle+"'" +
                ",LATITUD = '"+lat+"'" +
                ",LONGITUD ='"+lon+"'" +
                ",SUPERFICIE='"+sup+"'" +
                ",DESCRIPCION='"+descrip+"'" +
                ",PRECIO="+precio+
                ",ID_ZONA="+idComboZona+
                ",NRO_HABITACIONES="+NroH +
                ",NRO_BANHO="+NroB +
                ",ID_TIPO="+idComboTipo +
                ",ESTADO=1" +
                ",ID_OPERACION="+idComboOp +
                " WHERE CODIGO_INMUEBLE="+code;
            con.crearComando(SqlUP);
            con.Actualizar();
        }
    }
}