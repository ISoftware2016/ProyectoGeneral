﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Datos
{
    public class conexion
    {
        //private string CadConexion = "workstation id=inmocruz.mssql.somee.com;packet size=4096;user id=escalante_77_SQLLogin_2;pwd=2l8eftif9f;data source=inmocruz.mssql.somee.com;persist security info=False;initial catalog=inmocruz";
        private string CadConexion = "Data Source=(local);Initial Catalog=inmocruz;Integrated Security=True";
     //   private string CadConexion = "workstation id=inmocruz.mssql.somee.com;packet size=4096;user id=escalante_77_SQLLogin_2;pwd=e81yo3pa2j;data source=inmocruz.mssql.somee.com;persist security info=False;initial catalog=inmocruz";
        SqlCommand cmd;
        SqlConnection con;

        public conexion()
        {
            con = new SqlConnection(CadConexion);
        }

        public void crearComando(string cad)
        {
            con.ConnectionString = CadConexion;
            cmd = new SqlCommand(cad, con);
        }

        public string CadenaConexion()
        {
            SqlConnectionStringBuilder csb = new SqlConnectionStringBuilder();
            csb.DataSource = @"(local)";
            csb.InitialCatalog = "inmocruz";
            csb.IntegratedSecurity = true;

            return csb.ConnectionString;
        }
        public void AdicionarParametro(string parametro, object valor)
        {
            cmd.Parameters.AddWithValue(parametro, valor);
        }
        public void Insert()
        {
            using (con)
            {
                con.Open();
                cmd.ExecuteScalar();
                con.Close();
            }
        }
        public void Actualizar()
        {
            using (con)
            {
                con.Open();
                cmd.ExecuteScalar();
                con.Close();
            }
        }
        public void Eliminar()
        {
            using (con)
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }
        }
        public void IniciarConexion()
        {
            try
            {
                con.Open();
            }
            catch (Exception e) { }
        }
        public void CerrarConexion()
        {
            try
            {
                con.Close();
            }
            catch (Exception e) { }
        }
        public String ObtenerInformacion()
        {
            string cadena = "";
            using (con)
            {
                con.Open(); 
                SqlDataReader dr = cmd.ExecuteReader();
                int d = dr.FieldCount;
                while (dr.Read())
                {
                    for (int i = 0; i < d; i++)
                    {
                        cadena = cadena + dr.GetValue(i) + "";
                    }
                }
                dr.Close();
                con.Close();
                return cadena;
            }
        }
        public DataTable ObtenerConsulta()
        {
            DataTable tabla = new DataTable();
            con.Open();
            SqlDataAdapter adaptador = new SqlDataAdapter();
            adaptador.SelectCommand = cmd;
            adaptador.Fill(tabla);
            con.Close();
            return tabla;
        }

    }
}
