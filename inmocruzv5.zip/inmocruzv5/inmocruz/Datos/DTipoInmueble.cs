﻿using Datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Datos
{
    public class DTipoInmueble
    {
        public string NombreTabla = "TIPO_INMUEBLE";
        private conexion con = new conexion();
        public DataTable getComboTipo()
        {
            string sql = "Select ID_INMUEBLE, NOMBRE FROM " + NombreTabla;
            con.crearComando(sql);
            return con.ObtenerConsulta();
        }

        public string GetNombre(int id)
        {
            con.crearComando("SELECT NOMBRE FROM " + NombreTabla + " WHERE ID_INMUEBLE=" + id);
            return con.ObtenerInformacion();
        }
    }
}