﻿using Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Datos
{
    public class DLogin
    {
        public string NombreTabla = "LOG_IN";
        private conexion con = new conexion();

        public Boolean ValidarUsuario(int user, string pass)
        {
            con.crearComando("Select CONTRASENHA from " + NombreTabla + " where USUARIO = " + user);
            String pw = con.ObtenerInformacion(); 
            if (pw == pass)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        internal void InsertarCuenta(int CI, string p)
        {    
            string Sql;
            Sql = "INSERT INTO " + NombreTabla +
 "(USUARIO,CONTRASENHA,ESTADO) " +
                "VALUES " +
 "(@USUARIO, @CONTRASENHA,@ESTADO) " +
                "SELECT @@Identity";
            con.crearComando(Sql);
            con.AdicionarParametro("@USUARIO", CI);
            con.AdicionarParametro("@CONTRASENHA", p);
            con.AdicionarParametro("@ESTADO", 1);
            con.Insert();
        
        }

        internal string GetPass(int ci)
        {
            con.crearComando("Select CONTRASENHA from " + NombreTabla + "  where USUARIO = " + ci);
            return con.ObtenerInformacion();
        }

        public void SetPass(int Carnet, string pw)
        {
            string sql = "update LOG_IN set CONTRASENHA = '" + pw + "' where USUARIO = " + Carnet;
            con.crearComando(sql);
            con.Actualizar();
        }
    }
}