﻿using Datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Datos
{
    public class DPersona
    {
        public string NombreTabla = "PERSONA";
        private conexion con = new conexion();
        public DataTable getTabla()
        {
            string sql = "SELECT ci as Carnet, (Nombres + ' ' + Apellidos) as Nombre, FECHA_NACIMIENTO as Nacimiento, correo as Correo, telefono as Telefono  FROM " + NombreTabla;
            con.crearComando(sql);
            return con.ObtenerConsulta();
        }
        public String GetIDCargo(int user)
        {
            con.crearComando("Select ID_TIPO from PERSONA P where P.CI = " + user);
            return con.ObtenerInformacion();
        }

        public String GetCargo(int user)
        {
            con.crearComando("Select NOMBRE from PERSONA P ,TIPO T where T.ID_TIPO = P.ID_TIPO and P.CI = " + user);
            return con.ObtenerInformacion();
        }

        public String GetNombreCompleto(int user)
        {
            con.crearComando("Select NOMBRES + ' ' + APELLIDOS as name from PERSONA  where CI = " + user);
            return con.ObtenerInformacion();
        }


        public void Insertar(int CI, string Nombres, string App, string fecha, string correo, int telefono)
        {
            DateTime hoy = DateTime.Today;
            DateTime limite = DateTime.Today.AddMonths(2);
            string Sql;
            Sql = "INSERT INTO " + NombreTabla +
                "(CI, NOMBRES,APELLIDOS,FECHA_NACIMIENTO,CORREO,TELEFONO,FOTO,FECHA_INGRESO,FECHA_LIMITE,ESTADO,ID_TIPO) " +
                "VALUES " + "(@CI, @NOMBRES,@APELLIDOS,@FECHA_NACIMIENTO,@CORREO,@TELEFONO,@FOTO,@FECHA_INGRESO,@FECHA_LIMITE,@ESTADO,@ID_TIPO) " +
                "SELECT @@Identity";
            con.crearComando(Sql);

            con.AdicionarParametro("@CI", CI);
            con.AdicionarParametro("@NOMBRES", Nombres);
            con.AdicionarParametro("@APELLIDOS", App);
            con.AdicionarParametro("@FECHA_NACIMIENTO", fecha);
            con.AdicionarParametro("@CORREO", correo);
            con.AdicionarParametro("@TELEFONO", telefono);
            con.AdicionarParametro("@FOTO", "0.png");
            con.AdicionarParametro("@FECHA_INGRESO", hoy.ToString());
            con.AdicionarParametro("@FECHA_LIMITE", limite.ToString());
            con.AdicionarParametro("@ESTADO", 1);
            con.AdicionarParametro("@ID_TIPO", 2);

            con.Insert();

        }

        public string GetNombre(int ci)
        {
            con.crearComando("Select NOMBRES from PERSONA  where CI = " + ci);
            return con.ObtenerInformacion();
        }

        public string GetApp(int ci)
        {
            con.crearComando("Select APELLIDOS from PERSONA  where CI = " + ci);
            return con.ObtenerInformacion();
        }

        public string GetFechaN(int ci)
        {
            con.crearComando("Select FECHA_NACIMIENTO from PERSONA  where CI = " + ci);
            return con.ObtenerInformacion();
        }

        public string GetCorreo(int ci)
        {
            con.crearComando("Select CORREO from PERSONA  where CI = " + ci);
            return con.ObtenerInformacion();
        }

        public string GetTelefono(int ci)
        {
            con.crearComando("Select TELEFONO from PERSONA  where CI = " + ci);
            return con.ObtenerInformacion();
        }

        public string GetFoto(int ci)
        {
            con.crearComando("Select FOTO from PERSONA  where CI = " + ci);
            return con.ObtenerInformacion();
        }

        public void SetDatos(int Carnet, string p1, string p2, string p3, string p4, string p5)
        {
            string sql = "update PERSONA set "+
                "NOMBRES = '" + p1 + "'" +
                ",APELLIDOS = '" + p2 + "'" +
                ",FECHA_NACIMIENTO = '" + p3 + "'" +
                ",CORREO = '" + p4 + "'" +
                ",TELEFONO = " + p5 +
                " where CI = " + Carnet;
            con.crearComando(sql);
            con.Actualizar();
        }
    }
}