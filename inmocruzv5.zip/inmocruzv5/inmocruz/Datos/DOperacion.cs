﻿using Datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Datos
{
    public class DOperacion
    {
        public string NombreTabla = "OPERACION";
        private conexion con = new conexion();
        public DataTable getComboOperacion()
        {
            string sql = "Select ID_OPERACION, NOMBRE FROM " + NombreTabla;
            con.crearComando(sql);
            return con.ObtenerConsulta();
        }


        public string GetNombre(int id)
        {
            con.crearComando("SELECT NOMBRE FROM " + NombreTabla + " WHERE ID_OPERACION=" + id);
            return con.ObtenerInformacion();
        }

    }
}