﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Datos
{
    public class DPersonaInmueble
    {
        public string NombreTabla = "PERSONA_INMUEBLE";
        private conexion con = new conexion();

        public void Insertar(int CODIGO_INMUEBLE, int CI_PERSONA)
        {
            string Sql;
            Sql = "INSERT INTO " + NombreTabla +
 "(CODIGO_INMUEBLE,CI_PERSONA) " +
                "VALUES " +
 "(@CODIGO_INMUEBLE, @CI_PERSONA) " +
                "SELECT @@Identity";
            con.crearComando(Sql);
            con.AdicionarParametro("@CODIGO_INMUEBLE", CODIGO_INMUEBLE);
            con.AdicionarParametro("@CI_PERSONA", CI_PERSONA);
            con.Insert();
        }


        public DataTable getTabla(int ci)
        {
            string sql = "SELECT * FROM " + NombreTabla + " WHERE CI_PERSONA = " + ci.ToString();
            con.crearComando(sql);
            return con.ObtenerConsulta();
        }
        public bool VerificarRegistro(int p, int Carnet)
        {
            con.crearComando("Select * from " + NombreTabla + "  where CODIGO_INMUEBLE = " + p + " and CI_PERSONA = " + Carnet);
            string consulta = con.ObtenerInformacion();
            if (consulta == "")
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}