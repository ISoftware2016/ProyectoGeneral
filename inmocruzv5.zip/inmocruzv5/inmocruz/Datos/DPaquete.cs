﻿using Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Datos
{
    public class DPaquete
    {
        conexion con = new conexion();

        public String NombrePaquete(int id)
        {
            con.crearComando("Select NOMBRE from PAQUETE  where ID_PAQUETE = " + id);
            return con.ObtenerInformacion();
        }

        public int CantidadCUpaquete(int idPaquete){
            con.crearComando("select COUNT(*) from CU_PAQUETE where ID_PAQUETE =  " + idPaquete);
            return Convert.ToInt32(con.ObtenerInformacion());
        }

        

    }
}