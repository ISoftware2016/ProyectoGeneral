﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Datos
{
    public class DImagenInmueble
    {
        public string NombreTabla = "IMAGEN_INMUEBLE";
        private conexion con = new conexion();

        public void Insertar(int ID_INMUEBLE, string IMAGEN)
        {
            string Sql;
            Sql = "INSERT INTO " + NombreTabla +
 "(ID_INMUEBLE,IMAGEN) " +
                "VALUES " +
 "(@ID_INMUEBLE, @IMAGEN) " +
                "SELECT @@Identity";
            con.crearComando(Sql);
            con.AdicionarParametro("@ID_INMUEBLE", ID_INMUEBLE);
            con.AdicionarParametro("@IMAGEN", IMAGEN);
            con.Insert();
        }

        public string GetPrimeraImagen(int code)
        {
            con.crearComando("Select TOP 1 IMAGEN from " + NombreTabla + "  where ID_INMUEBLE = " + code);
            return con.ObtenerInformacion();
        }

        internal bool VerificarImagen(int code)
        {
            con.crearComando("Select * from " + NombreTabla + " where ID_INMUEBLE = " + code);
            string consulta = con.ObtenerInformacion();
            if (consulta == "")
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        internal int GetCantidaImagen(int code)
        {
            con.crearComando("Select count(*) from " + NombreTabla + "  where ID_INMUEBLE = " + code);
            return Convert.ToInt32(con.ObtenerInformacion());
        }

        internal DataTable GetImagenesInmueble(int codigoInmueble)
        {
            string sql = "SELECT * FROM " + NombreTabla + " WHERE ID_INMUEBLE = " + codigoInmueble;
            con.crearComando(sql);
            return con.ObtenerConsulta();
        }
    }
}